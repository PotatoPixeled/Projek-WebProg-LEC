<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo asset('css/editproduct.css')?>" type="text/css">
    <div class="forms">
        <form action="<?php echo e(url('update',$product->id)); ?>" enctype="multipart/form-data"  method="POST">
            <?php echo csrf_field(); ?>
                <div class="inputs">
                    Category: <input type="text" name="category" id='category'  maxlength="30" value="<?php echo e($product['category']); ?>">
                </div>
                <div class="inputs">
                    Title: <input type="text" name='title' id='title' value="<?php echo e($product['title']); ?>">
                </div>
                <div class="inputs">
                    Description: <input type="text" name='description' id='description' value="<?php echo e($product['description']); ?>">
                </div>
                <div class="inputs">
                    Price:  <input type="integer" name='price' id='price' value="<?php echo e($product['price']); ?>">
                </div>
                <div class="inputs">
                    Stock:  <input type="integer" name='stock' id='stock' value="<?php echo e($product['stock']); ?>">
                </div>
                <div class="inputs">
                    Image: <input type="file" name="image" id="image" value="<?php echo e($product['image']); ?>">
                </div>

                <input type="submit" value="Update">

                <button><a href="/home">back</a></button>
        </form>
    </div>


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SUNIB\Semester 5\Web Programming\Project Lab Done\ProjectLab\resources\views/editproduct.blade.php ENDPATH**/ ?>
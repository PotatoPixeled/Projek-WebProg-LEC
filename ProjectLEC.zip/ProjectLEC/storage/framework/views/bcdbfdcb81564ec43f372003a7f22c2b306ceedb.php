<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo asset('css/home.css')?>" type="text/css">


    <div class="list">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="box">
                <div class="detail"><img src="<?php echo e(asset('images')); ?>/<?php echo e($product->image); ?>" /></div>
                <div class="container">
                    <div class="details">
                        <div class="detail">Title:  <?php echo e($product->title); ?> </div>
                        <div class="detail">Description:    <?php echo e($product->description); ?></div>
                    </div>

                    <div class="edit-button">
                        <?php if(Auth::user()->name == "admin"): ?>
                            <button><a href=<?php echo e("edit/".$product['id']); ?>>edit</a></button>
                        <?php endif; ?>
                    </div>
                    <div class="detail-button">
                        <?php if(Auth::user()->name != "admin"): ?>
                            <button><a href="<?php echo e(route('productdetail', $product->id)); ?>">Detail Product</a></button>
                        <?php endif; ?>
                    </div>


            </div>



        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SUNIB\Semester 5\Web Programming\Project Lab Done\ProjectLab\resources\views/home.blade.php ENDPATH**/ ?>
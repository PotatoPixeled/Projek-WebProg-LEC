<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo asset('css/login.css')?>" type="text/css">

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <p><strong>Whoops!</strong></p>
            <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="content">
        <div class="forms">
            <form action="/login" method="POST">
                <?php echo csrf_field(); ?>
                    <div class="inputs">
                        Email: <input type="email" name='email' id='email' value=<?php echo e(Cookie::get('email') != null ? Cookie::get('email') : ""); ?>>
                    </div>

                    <div class="inputs">
                        Password: <input type="password" name='password' id='password'>
                    </div>

                    <div class="inputs">
                        <input type="checkbox" name="remember" id="remember"> Remember Me
                    </div>

                    <button type="submit" id="login-button">Login</button>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SUNIB\Semester 5\Web Programming\Projek Lab\ProjectLab\resources\views/auth/login.blade.php ENDPATH**/ ?>
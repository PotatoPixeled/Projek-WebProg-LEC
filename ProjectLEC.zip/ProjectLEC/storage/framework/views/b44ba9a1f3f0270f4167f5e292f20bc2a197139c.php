<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo asset('css/manageuser.css')?>" type="text/css">
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <div class="listorder">
                <div class="item">
                     <?php echo e($user->name); ?>

                </div>

                <div class="delete">
                    <a href= <?php echo e("delete/".$user['id']); ?> ><button id="delete-but"> Delete</button></a>
                </div>
            </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <button><a href="/home">back</a></button>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SUNIB\Semester 5\Web Programming\Projek Lab\ProjectLab\resources\views/manageuser.blade.php ENDPATH**/ ?>
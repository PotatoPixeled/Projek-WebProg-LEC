<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo asset('css/edituser.css')?>" type="text/css">

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <p><strong>Whoops!</strong></p>
            <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>


    <div class="forms">
        <form action="<?php echo e(url('updateuser')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="inputs">
                Nama: <br><input type="text" name="name" id='name' maxlength="30" value="<?php echo e($user['name']); ?>">
            </div>
            <div class="inputs">
                Email: <br><input type="email" name='email' id='email' value="<?php echo e($user['email']); ?>">
            </div>
            <div class="inputs">
                Password: <br><input type="password" name='password' id='password'>
            </div>
            <div class="inputs">
                Confirm Password:  <br><input type="password" name='confirm_password' id='confirm_password'>
            </div>
            <div class="gender">
                <input type="radio" name="gender" value="male"> Male<br>
                <input type="radio" name="gender" value="female"> Female<br>
            </div>

            <input type="submit" value="submit">
            <button><a href="/home">back</a></button>
        </form>
    </div>



    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SUNIB\Semester 5\Web Programming\Projek Lab\ProjectLab\resources\views/edituser.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo asset('css/insertproduct.css')?>" type="text/css">

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <p><strong>Whoops!</strong></p>
            <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>


    <div class="forms">
        <form action="/insertproduct" enctype="multipart/form-data"  method="POST">
            <?php echo csrf_field(); ?>
                <div class="inputs">
                    Category: <input type="text" name="category" id='category'  maxlength="30">
                </div>
                <div class="inputs">
                    Title: <input type="text" name='title' id='title'>
                </div>
                <div class="inputs">
                    Description: <input type="text" name='description' id='description'>
                </div>
                <div class="inputs">
                    Price:  <input type="integer" name='price' id='price'>
                </div>
                <div class="inputs">
                    Stock:  <input type="integer" name='stock' id='stock'>
                </div>
                <div class="inputs">
                    Image: <input type="file" name="image" id="image">
                </div>

                <input type="submit" value="submit">
        </form>
    </div>

    <button><a href="/home">back</a></button>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SUNIB\Semester 5\Web Programming\Projek Lab\ProjectLab\resources\views/insertproduct.blade.php ENDPATH**/ ?>
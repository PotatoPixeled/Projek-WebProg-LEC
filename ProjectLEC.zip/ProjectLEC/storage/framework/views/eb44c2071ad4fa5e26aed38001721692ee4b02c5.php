<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo asset('css/detail.css')?>" type="text/css">

    <div class="container">
        <div class="left">
            <img src="<?php echo e(asset('images')); ?>/<?php echo e($product->image); ?>" />
        </div>
        <div class="right">
            <div class="detail">Title:  <?php echo e($product->title); ?> </div>
            <div class="detail">Category:  <?php echo e($product->category); ?> </div>
            <div class="detail">Description:    <?php echo e($product->description); ?></div>
            <div class="detail">Price:    <?php echo e($product->price); ?></div>
            <div class="detail">Stock:    <?php echo e($product->stock); ?></div>

            <button><a href="">Add to Cart</a></button>
        </div>
    </div>



    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SUNIB\Semester 5\Web Programming\Projek Lab\ProjectLab\resources\views/detail.blade.php ENDPATH**/ ?>
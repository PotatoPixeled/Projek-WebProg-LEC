<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
</head>
<body>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <p><strong>Whoops!</strong></p>
            <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>


    <div class="forms">
        <form action="/login" method="POST">
            <?php echo csrf_field(); ?>
                <div class="inputs">
                    Email: <input type="email" name='email' id='email'>
                </div>

                <div class="inputs">
                    Password: <input type="password" name='password' id='password'>
                </div>

                <div class="inputs">
                    <input type="checkbox" name="remember" id="remember"> Remember Me
                </div>

                <button type="submit">Login</button>
        </form>
    </div>
</body>
</html>
<?php /**PATH F:\SUNIB\Semester 5\Web Programming\Projek Lab\ProjectLab\resources\views/login.blade.php ENDPATH**/ ?>